/**
 * Clase que permite calcular medias, comprobar si una nota esta aprobada,
 * obtener su calificacion y calcular una nota final teniendo en cuenta las faltas.
 * La nota final se calcula restando 0.1 puntos por cada falta a la media,
 * sin permitir que el resultado sea inferior a 0.
 *
 * @author Esteban
 * @version 1.0
 */
public class Notas {

    /** Nota minima necesaria para aprobar. */
    public static final double NOTA_APROBADO = 5.0;

    /**
     * Calcula la media de tres notas.
     *
     * @param nota1 primera nota
     * @param nota2 segunda nota
     * @param nota3 tercera nota
     * @return la media de las tres notas
     */
    public static double media(double nota1, double nota2, double nota3) {
        return (nota1 + nota2 + nota3) / 3;
    }

    /**
     * Comprueba si una nota es suficiente para aprobar.
     *
     * @param nota nota que se quiere comprobar
     * @return true si la nota es igual o superior a 5, y false si es inferior
     */
    public static boolean estaAprobado(double nota) {
        return nota >= NOTA_APROBADO;
    }

    /**
     * Devuelve la calificacion correspondiente a una nota: Insuficiente
     * para menos de 5, Suficiente desde 5 hasta menos de 6, Bien desde 6
     * hasta menos de 7, Notable desde 7 hasta menos de 9 y Sobresaliente
     * desde 9 en adelante.
     *
     * @param nota nota que se quiere calificar
     * @return el nombre de la calificacion correspondiente
     */
    public static String calificacion(double nota) {
        if (nota < 5) {
            return "Insuficiente";
        } else if (nota < 6) {
            return "Suficiente";
        } else if (nota < 7) {
            return "Bien";
        } else if (nota < 9) {
            return "Notable";
        } else {
            return "Sobresaliente";
        }
    }

    /**
     * Calcula la nota final restando 0.1 puntos por cada falta a la media.
     * Si el resultado es negativo, devuelve 0. Por ejemplo, notaFinal(0.5, 10)
     * devuelve 0.0: las diez faltas restan 1 punto a 0.5, dando -0.5,
     * pero el metodo limita la nota minima a cero.
     *
     * @param media media inicial del alumno
     * @param faltas numero de faltas
     * @return la nota final, que nunca sera inferior a 0
     */
    public static double notaFinal(double media, int faltas) {
        double nota = media - faltas * 0.1;
        if (nota < 0) {
            nota = 0;
        }
        return nota;
    }

    /**
     * Muestra por pantalla el nombre del alumno, su nota y su calificacion.
     *
     * @param nombre nombre del alumno
     * @param nota nota del alumno
     */
    public static void mostrarBoletin(String nombre, double nota) {
        System.out.println(nombre + ": " + nota
                + " (" + calificacion(nota) + ")");
    }

    /**
     * Metodo principal que prueba los metodos de la clase Notas y muestra
     * los resultados por pantalla.
     *
     * @param args argumentos recibidos desde la linea de comandos
     */
    public static void main(String[] args) {
        // Prueba solicitada en el ejercicio: debe devolver 0.0.
        System.out.println("Nota final de 0.5 con 10 faltas: " + notaFinal(0.5, 10));

        double m = media(6, 7.5, 9);
        System.out.println("Media: " + m);
        System.out.println("¿Aprobado? " + estaAprobado(m));
        System.out.println("Nota final con 4 faltas: " + notaFinal(m, 4));
        mostrarBoletin("Lucía", 8.5);
    }
}
